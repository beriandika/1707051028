<?php
define("DB_HOST","localhost");
define("DB_USER","id9974457_user");
define("DB_PASSWORD","12345678");
define("DB_NAME","id9974457_beridb");

// echo DB_HOST;
